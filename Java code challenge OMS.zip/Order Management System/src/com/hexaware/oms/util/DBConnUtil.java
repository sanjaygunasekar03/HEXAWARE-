package com.hexaware.oms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    public static Connection getDBConn() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/oms_db"; 
        String username = "root"; 
        String password = "sanjusid2003@"; 
        return DriverManager.getConnection(url, username, password);
    }
}

