package com.hexaware.oms.dao;

import com.hexaware.oms.entity.Product;
import com.hexaware.oms.entity.User;
import com.hexaware.oms.exception.UserNotFoundException;
import com.hexaware.oms.exception.OrderNotFoundException;

import java.util.List;

public interface IOrderManagementRepository {
    void createUser(User user) throws Exception;
    void createProduct(User user, Product product) throws Exception;
    void createOrder(User user, List<Product> products) throws Exception;
    void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;
    List<Product> getAllProducts() throws Exception;
    List<Product> getOrderByUser(User user) throws Exception;
}


