package com.hexaware.oms.dao;

import com.hexaware.oms.entity.Product;
import com.hexaware.oms.entity.User;
import com.hexaware.oms.exception.UserNotFoundException;
import com.hexaware.oms.exception.OrderNotFoundException;
import com.hexaware.oms.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderProcessor implements IOrderManagementRepository {
    private Connection conn;

    public OrderProcessor() throws SQLException {
        conn = DBConnUtil.getDBConn();
    }

    @Override
    public void createUser(User user) throws Exception {
        PreparedStatement pst = conn.prepareStatement(
            "INSERT INTO users (userId, username, password, role) VALUES (?, ?, ?, ?)");
        pst.setInt(1, user.getUserId());
        pst.setString(2, user.getUsername());
        pst.setString(3, user.getPassword());
        pst.setString(4, user.getRole());
        pst.executeUpdate();
    }

    @Override
    public void createProduct(User user, Product product) throws Exception {
        if (!"Admin".equalsIgnoreCase(user.getRole())) {
            throw new Exception("Only Admin users can create products!");
        }
        PreparedStatement pst = conn.prepareStatement(
            "INSERT INTO products (productId, productName, description, price, quantityInStock, type) " +
            "VALUES (?, ?, ?, ?, ?, ?)");
        pst.setInt(1, product.getProductId());
        pst.setString(2, product.getProductName());
        pst.setString(3, product.getDescription());
        pst.setDouble(4, product.getPrice());
        pst.setInt(5, product.getQuantityInStock());
        pst.setString(6, product.getType());
        pst.executeUpdate();
    }

    @Override
    public void createOrder(User user, List<Product> products) throws Exception {
        // Check if user exists
        PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM users WHERE userId = ?");
        checkUser.setInt(1, user.getUserId());
        ResultSet rs = checkUser.executeQuery();
        if (!rs.next()) {
            createUser(user);
        }

        for (Product product : products) {
            PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO orders (userId, productId) VALUES (?, ?)");
            pst.setInt(1, user.getUserId());
            pst.setInt(2, product.getProductId());
            pst.executeUpdate();
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try {
            PreparedStatement pst = conn.prepareStatement(
                "DELETE FROM orders WHERE userId = ? AND orderId = ?");
            pst.setInt(1, userId);
            pst.setInt(2, orderId);
            int rows = pst.executeUpdate();
            if (rows == 0) {
                throw new OrderNotFoundException("Order not found with given User ID and Order ID.");
            }
        } catch (SQLException e) {
            throw new UserNotFoundException("User ID not found while cancelling order.");
        }
    }

    @Override
    public List<Product> getAllProducts() throws Exception {
        List<Product> productList = new ArrayList<>();
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM products");

        while (rs.next()) {
            Product p = new Product(
                rs.getInt("productId"),
                rs.getString("productName"),
                rs.getString("description"),
                rs.getDouble("price"),
                rs.getInt("quantityInStock"),
                rs.getString("type")
            );
            productList.add(p);
        }
        return productList;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws Exception {
        List<Product> orders = new ArrayList<>();
        PreparedStatement pst = conn.prepareStatement(
            "SELECT p.productId, p.productName, p.description, p.price, p.quantityInStock, p.type " +
            "FROM products p INNER JOIN orders o ON p.productId = o.productId WHERE o.userId = ?");
        pst.setInt(1, user.getUserId());
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            Product p = new Product(
                rs.getInt("productId"),
                rs.getString("productName"),
                rs.getString("description"),
                rs.getDouble("price"),
                rs.getInt("quantityInStock"),
                rs.getString("type")
            );
            orders.add(p);
        }
        return orders;
    }

    // ✅ Added new method to view all orders
    public void viewAllOrders() throws Exception {
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM orders");
        System.out.println("\nAvailable Orders:");
        while (rs.next()) {
            System.out.println("Order ID: " + rs.getInt("orderId") +
                               ", User ID: " + rs.getInt("userId") +
                               ", Product ID: " + rs.getInt("productId"));
        }
    }
}



