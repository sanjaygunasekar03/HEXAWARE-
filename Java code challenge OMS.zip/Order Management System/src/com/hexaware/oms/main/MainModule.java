package com.hexaware.oms.main;

import com.hexaware.oms.dao.OrderProcessor;
import com.hexaware.oms.entity.Product;
import com.hexaware.oms.entity.User;
import com.hexaware.oms.exception.OrderNotFoundException; 
import com.hexaware.oms.exception.UserNotFoundException; 

import java.util.*;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            OrderProcessor op = new OrderProcessor();

            System.out.println("======================================");
            System.out.println("        ORDER MANAGEMENT SYSTEM       ");
            System.out.println("======================================");

            while (true) {
                System.out.println("\n1. Create User");
                System.out.println("2. Create Product");
                System.out.println("3. Create Order");
                System.out.println("4. Cancel Order");
                System.out.println("5. Get All Products");
                System.out.println("6. Get Orders by User");
                System.out.println("7. View All Orders");
                System.out.println("8. Exit");
                System.out.print("Enter choice: ");
                int choice = Integer.parseInt(sc.nextLine());

                try {
                    switch (choice) {
                        case 1:
                            System.out.print("Enter User ID: ");
                            int userId = Integer.parseInt(sc.nextLine());
                            System.out.print("Enter Username: ");
                            String username = sc.nextLine();
                            System.out.print("Enter Password: ");
                            String password = sc.nextLine();
                            System.out.print("Enter Role (Admin/User): ");
                            String role = sc.nextLine();
                            User user = new User(userId, username, password, role);
                            op.createUser(user);
                            System.out.println("User created successfully!");
                            break;

                        case 2:
                            System.out.print("Enter Admin User ID: ");
                            int adminId = Integer.parseInt(sc.nextLine());
                            User admin = new User(adminId, "", "", "Admin");

                            System.out.print("Enter Product ID: ");
                            int productId = Integer.parseInt(sc.nextLine());
                            System.out.print("Enter Product Name: ");
                            String productName = sc.nextLine();
                            System.out.print("Enter Product Description: ");
                            String description = sc.nextLine();
                            System.out.print("Enter Product Price: ");
                            double price = Double.parseDouble(sc.nextLine());
                            System.out.print("Enter Quantity in Stock: ");
                            int quantity = Integer.parseInt(sc.nextLine());
                            System.out.print("Enter Product Type (Electronics/Clothing): ");
                            String type = sc.nextLine();

                            Product product = new Product(productId, productName, description, price, quantity, type);
                            op.createProduct(admin, product);
                            System.out.println("Product created successfully!");
                            break;

                        case 3:
                            System.out.print("Enter User ID for placing Order: ");
                            int orderUserId = Integer.parseInt(sc.nextLine());
                            User orderUser = new User(orderUserId, "", "", "User");

                            System.out.print("Enter number of products to order: ");
                            int n = Integer.parseInt(sc.nextLine());

                            List<Product> products = new ArrayList<>();
                            for (int i = 0; i < n; i++) {
                                System.out.print("Enter Product ID: ");
                                int pId = Integer.parseInt(sc.nextLine());
                                products.add(new Product(pId, "", "", 0, 0, ""));
                            }
                            op.createOrder(orderUser, products);
                            System.out.println("Order placed successfully!");
                            break;

                        case 4:
                            System.out.print("Enter User ID to cancel order: ");
                            int cancelUserId = Integer.parseInt(sc.nextLine());
                            System.out.print("Enter Order ID to cancel: ");
                            int cancelOrderId = Integer.parseInt(sc.nextLine());
                            op.cancelOrder(cancelUserId, cancelOrderId);
                            System.out.println("Order cancelled successfully!");
                            break;

                        case 5:
                            List<Product> allProducts = op.getAllProducts();
                            System.out.println("\nAvailable Products:");
                            for (Product p : allProducts) {
                                System.out.println(p);
                            }
                            break;

                        case 6:
                            System.out.print("Enter User ID to view Orders: ");
                            int searchUserId = Integer.parseInt(sc.nextLine());
                            List<Product> orders = op.getOrderByUser(new User(searchUserId, "", "", ""));
                            System.out.println("\nProducts ordered by User:");
                            if (orders.isEmpty()) {
                                System.out.println("No orders found for this user.");
                            } else {
                                for (Product p : orders) {
                                    System.out.println(p);
                                }
                            }
                            break;

                        case 7:
                            op.viewAllOrders();
                            break;

                        case 8:
                            System.out.println("Exiting... Thank you for using the Order Management System!");
                            sc.close();
                            System.exit(0);
                            break;

                        default:
                            System.out.println("Invalid choice! Please select a valid option.");
                    }

                } catch (OrderNotFoundException e) {
                    System.out.println(e.getMessage()); 
                } catch (UserNotFoundException e) {
                    System.out.println(e.getMessage()); 
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input! Please enter valid numbers where required.");
                } catch (Exception e) {
                    System.out.println("Something went wrong. Please try again.");
                }
            }

        } catch (Exception e) {
            System.out.println("Unable to start Order Management System. Please check your database connection or configuration.");
        }
    }
}



